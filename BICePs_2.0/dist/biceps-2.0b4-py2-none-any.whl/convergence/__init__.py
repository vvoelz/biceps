#!/usr/bin/env python

# make compatible with python 3
from __future__ import print_function

"""BICePs - Bayesian Inference of Conformational Populations, Version 2.0"""


